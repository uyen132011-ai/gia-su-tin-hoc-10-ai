# Gia sư AI Tin học 10

## Triển khai nhanh bằng Vercel + GitHub

1. Tải và giải nén tệp ZIP.
2. Tạo repository mới trên GitHub, tải toàn bộ nội dung trong thư mục này lên repository.
3. Mở https://vercel.com/ và đăng nhập bằng GitHub.
4. Chọn **Add New → Project**, import repository vừa tạo, rồi Deploy.
5. Vào **Project → Settings → Environment Variables**. Thêm:
   - Name: `OPENAI_API_KEY`
   - Value: API key bạn tạo trong OpenAI Platform
   - Environment: Production (nên chọn Preview nếu muốn thử trước)
6. (Tuỳ chọn) Thêm biến `OPENAI_MODEL` với tên model mà tài khoản API của bạn có quyền dùng. Mặc định hiện tại trong mã là `gpt-6-astra`; nếu model này không khả dụng với tài khoản của bạn, hãy đổi sang model được hiển thị trong tài liệu/API dashboard của bạn.
7. Lưu biến môi trường và vào **Deployments → Redeploy** để triển khai lại.
8. Mở URL Vercel được cấp và thử gửi câu hỏi.

## Tạo API key

- Đăng nhập https://platform.openai.com/
- Mở phần API keys: https://platform.openai.com/api-keys
- Tạo secret key mới, sao chép và cất an toàn.
- Không gửi key cho người khác, không đưa vào `public/index.html`, GitHub hoặc ảnh chụp màn hình.
- ChatGPT Free và API billing là hai hệ thống riêng; có thể cần thiết lập phương thức thanh toán/hạn mức tại https://platform.openai.com/settings/organization/billing/overview.

## Bảo mật

- API key chỉ được đọc trên serverless function `api/chat.js` qua `process.env.OPENAI_API_KEY`.
- Không đặt API key trong HTML hay biến `NEXT_PUBLIC_*`.
- Bản mẫu chưa có đăng nhập người dùng hoặc giới hạn chống lạm dụng; trước khi chia sẻ công khai rộng rãi, hãy cân nhắc thêm rate limiting, CAPTCHA hoặc xác thực để tránh người khác lạm dụng hạn mức API.
- Không gửi thông tin cá nhân nhạy cảm vào chatbot.

## Chạy thử tại máy tính (tuỳ chọn)

Cài Node.js LTS, mở terminal tại thư mục dự án và chạy:
```bash
npm install
npm install -g vercel
vercel dev
```
Thiết lập `OPENAI_API_KEY` trong cấu hình môi trường local hoặc dùng `vercel env pull .env.local` sau khi đã liên kết dự án Vercel. Không commit `.env.local` lên GitHub.
