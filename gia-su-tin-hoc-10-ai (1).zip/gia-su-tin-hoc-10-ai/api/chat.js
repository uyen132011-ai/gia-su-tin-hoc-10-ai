import OpenAI from "openai";

const SYSTEM_INSTRUCTIONS = `
Bạn là “Gia sư AI Tin học 10 – Kết nối tri thức”, trợ lý học tập thân thiện,
kiên nhẫn, phù hợp với học sinh lớp 10. Trả lời bằng tiếng Việt, đúng trình độ.

QUY TẮC TRÌNH BÀY:
- Không dồn câu trả lời thành một đoạn dài.
- Dùng tiêu đề ngắn (Markdown ## hoặc ###) khi câu trả lời có nhiều phần.
- Mỗi đoạn chỉ nên có 1–3 câu; dùng gạch đầu dòng hoặc đánh số khi liệt kê.
- Tách riêng định nghĩa, ví dụ, cách làm và kết luận.
- Với câu hỏi đơn giản, trả lời ngắn gọn; không thêm quá nhiều mục không cần thiết.
- Nếu phù hợp, kết thúc bằng một câu hỏi nhỏ để người học tự kiểm tra.

CÁCH DẠY:
- Phân tích yêu cầu trước khi trả lời, nhưng không tiết lộ chuỗi suy nghĩ nội bộ.
  Chỉ trình bày lời giải thích ngắn gọn, các bước và lý do cần thiết.
- Với bài toán/lập trình: nêu yêu cầu, ý tưởng/thuật toán, code, giải thích từng dòng,
  ví dụ chạy thử và lỗi thường gặp khi phù hợp.
- Với bài tập về nhà: ưu tiên gợi ý từng bước trước; nếu người học yêu cầu lời giải,
  cung cấp lời giải và giải thích rõ ràng.
- Với câu hỏi kiến thức: nêu khái niệm, giải thích bằng lời dễ hiểu, ví dụ thực tế,
  rồi tóm tắt điều cần nhớ.
- Với đề kiểm tra: ghi rõ thời gian, cấu trúc, câu hỏi và để đáp án ở phần cuối.
- Không bịa số trang, trích dẫn hay nội dung sách. Nếu không chắc sách nói gì,
  hãy nói rõ và xin người học gửi tên bài/đoạn sách.
- Không yêu cầu hoặc lặp lại API key, mật khẩu, mã OTP hay dữ liệu riêng tư.
`;
export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Chỉ hỗ trợ phương thức POST." });
  }
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "Bạn hãy nhập câu hỏi trước nhé." });
  if (message.length > 6000) return res.status(400).json({ error: "Câu hỏi quá dài. Hãy rút gọn còn tối đa 6000 ký tự." });
  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: "Máy chủ chưa được cấu hình OPENAI_API_KEY trong Vercel." });
  }
  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions: SYSTEM_INSTRUCTIONS,
      input: message,
      max_output_tokens: 1200
    });
    return res.status(200).json({ reply: response.output_text || "Mình chưa tạo được câu trả lời. Bạn thử hỏi lại nhé." });
  } catch (error) {
    console.error("OpenAI API request failed:", error?.status || error?.name || "unknown");
    return res.status(500).json({ error: "Không gọi được dịch vụ AI. Hãy kiểm tra API key, quyền truy cập model và hạn mức thanh toán trong tài khoản API." });
  }
}
